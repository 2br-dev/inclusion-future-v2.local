--------------------
dateAgo
--------------------
Author: Vasiliy Naumkin <bezumkin@yandex.ru>
--------------------

Snippet that makes your dates look cool.
Use it as output filter: [[+publishedon:dateAgo]]


--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/bezumkin/dateAgo/issues
--------------------
Thanks to LiveStreet CMS for the algorithm.